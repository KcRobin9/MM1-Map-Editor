BRIDGE_ORIENTATION_ERROR = f"""
***ERROR***
Invalid Bridge Orientation.
Please choose from one of the following: NORTH, SOUTH, EAST, WEST,
NORTH_EAST, NORTH_WEST, SOUTH_EAST, SOUTH_WEST or set the orientation
using a numeric value between 0 and 360 degrees.
"""