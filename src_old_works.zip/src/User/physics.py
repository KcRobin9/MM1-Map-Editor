# Available indices: 94, 95, 96, 97, 98
custom_physics = {
    97: {"friction": 20.0, "elasticity": 0.01, "drag": 0.0},  # Sticky
    98: {"friction": 0.1, "elasticity": 0.01, "drag": 0.0}    # Slippery
}