class Facade:
    BUILDING_ORANGE_WITH_WINDOWS = "ofbldg02"
    
    WALL_FREEWAY = "freewaywall02"
    RAIL_WATER = "t_rail01"
    
    SHOP_SUIT = "dfsuitstore"
    SHOP_PIZZA = "hfpizza"
    SHOP_SODA = "ofsodashop"
    SHOP_LIQUOR = "cfliquor"
    
    HOME_ONE = "OFHOME01"
    HOME_TWO = "OFHOME02"
    HOME_THREE = "OFHOME03"